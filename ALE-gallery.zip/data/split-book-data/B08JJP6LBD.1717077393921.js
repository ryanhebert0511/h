window.bookSummaryJSON = "The Bible Recap"; 
