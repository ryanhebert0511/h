window.bookSummaryJSON = "If you move out of the marital residence have you abandoned it?#rockwalldivorce #Dallasdivorcelawyer #collincountydivorce"; 
